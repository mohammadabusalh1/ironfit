package com.example.ironfit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
