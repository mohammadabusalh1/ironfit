import 'package:get/get.dart';



class MyGymController extends GetxController {
  void onTap() {
     // Get.to(() => MyGymScreen());
  }
  void back () {
    Get.back();
  }
}
